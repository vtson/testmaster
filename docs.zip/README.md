# Vue 3 + TypeScript + Vite

This template should help get you started developing with Vue 3 and TypeScript in Vite. The template uses Vue 3 `<script setup>` SFCs, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

Learn more about the recommended Project Setup and IDE Support in the [Vue Docs TypeScript Guide](https://vuejs.org/guide/typescript/overview.html#project-setup).


# Modern Master Strike — Single‑Page Application

This repository contains a modernized single‑page application (SPA) for exploring,
filtering, and searching the complete Master Strike card library.

The application is built with a clear separation of concerns:
- Client and browser responsibilities
- Frontend UI lifecycle and rendering
- Application logic and data preparation
- Passive static assets

All architectural intent is documented and treated as part of the system.

---

## Architecture Overview

At a high level, the application:

1. Loads all card data and metadata once at startup
2. Prepares in‑memory lookup and search structures
3. Exposes pure query functions for filtering and searching
4. Uses Vue reactivity to render and update the UI declaratively
5. Fetches static assets (images) lazily at runtime

There are **no runtime data fetches** and **no imperative rendering logic**.

---

## Architecture & Design Documentation

The authoritative architectural documentation lives in the `/docs` directory.

➡️ **Start here:** [`docs/README.md`](docs/README.md)

That index links to:

- The cross‑functional flow diagram
- Data source inventory
- Service‑layer contract (`cardData`)
- Runtime state model
- Performance invariants
- Test boundaries

Together, these documents define how the system is intended to work and what must
not change without an explicit design decision.

---

## Repository Structure
.
├─ src/            # Application source code
├─ public/         # Static assets (images, etc.)
├─ docs/           # Architecture & design documentation
├─ package.json
└─ README.md       # This file

---

## Development Philosophy

This project follows these core principles:

- **Initialize once**
- **Operate on in‑memory data**
- **Derive state reactively**
- **Render declaratively**
- **Fetch assets lazily**
- **Protect architectural boundaries**

Performance and clarity are intentional design goals, not accidental outcomes.

---

## Getting Started

Standard frontend tooling is used.

```bash
npm install
npm run dev


The application runs entirely client‑side.

Contributing
Before making changes:

Review the architecture documentation in /docs
Identify which layer your change affects
Preserve existing invariants unless intentionally changing the design
Update documentation when architectural intent changes

Documentation is considered part of the system.

License / Attribution
This project modernizes the presentation and interaction model for the
Master Strike card library.
(Additional licensing or attribution details can be added here if required.)

---

## ✅ Why this README works

- ✅ Short and readable
- ✅ Clearly points to `/docs` as the source of truth
- ✅ Explains *what the app does* without duplicating design docs
- ✅ Sets expectations for contributors
- ✅ Ages well as the codebase evolves

---

## ✅ Final recommended file layout (authoritative)

README.md
docs/
├─ README.md
├─ flow-diagram.pdf
├─ data-sources.md
├─ cardData-service.md
├─ runtime-state-model.md
├─ performance-invariants.md
└─ test-boundaries.md

