# Architecture & Design Documentation

This directory contains the architectural documentation for the
Modern Master Strike single‑page application (SPA).

These documents describe **how the application behaves**, **what it depends on**,
**how state flows at runtime**, and **which constraints must not be violated**
as the codebase evolves.

Together, they form the authoritative reference for system design decisions.

---

## How to Read This Documentation

If you are new to the project, read the documents **in this order**:

1. **Flow Diagram** – Understand system behavior and responsibilities
2. **Data Sources** – Understand what data exists and when it is loaded
3. **Service Contract** – Understand application‑logic responsibilities
4. **Runtime State Model** – Understand reactive UI behavior
5. **Performance Invariants** – Understand what must not change
6. **Test Boundaries** – Understand what and how to test

---

## Document Index

### 1. Cross‑Functional Flow Diagram
**Purpose:** High‑level system behavior and ownership boundaries

- **File:** `flow-diagram.pdf`
- Describes initialization vs runtime behavior
- Separates client, frontend, application logic, and static assets
- Explains the reactive runtime interaction loop

_Source:_  
See the Visio diagram: **Single‑Page Application (SPA) Cross‑Functional Flow**

---

### 2. Data Source Inventory
**File:** `data-sources.md`

- Lists all data sources used by the application
- Specifies when data is loaded (initialization vs runtime)
- Identifies ownership and mutability
- Establishes “load‑once, derive‑many” intent

---

### 3. `cardData` Service Contract
**File:** `cardData-service.md`

- Defines responsibilities of the application‑logic layer
- Documents module‑scope initialization behavior
- Specifies which operations are allowed and forbidden
- Serves as a guardrail for future refactors

---

### 4. Runtime State Model
**File:** `runtime-state-model.md`

- Defines all mutable and derived UI state
- Explains how Vue reactivity drives rendering
- Documents runtime interaction paths
- Prevents mutation of derived data

---

### 5. Performance Invariants
**File:** `performance-invariants.md`

- Captures intentional performance characteristics
- Defines non‑negotiable constraints (no runtime data fetches, no re‑indexing)
- Explains why these constraints exist
- Acts as an early warning system for regressions

---

### 6. Test Boundaries
**File:** `test-boundaries.md`

- Defines what to test and where
- Aligns tests with architectural boundaries
- Identifies explicit anti‑patterns
- Ensures tests reinforce design intent

---

## Design Principles (Summary)

This application is built on the following principles:

- **Initialize once**
- **Operate on in‑memory data**
- **Derive state reactively**
- **Render declaratively**
- **Fetch assets lazily**
- **Avoid cross‑layer coupling**

All documentation in this directory exists to protect these principles.

---

## Change Management

Any change that affects:

- Data loading behavior
- Service responsibilities
- Runtime state flow
- Performance characteristics

must be reflected in **both the code and these documents**.

Documentation is treated as part of the architecture, not as an afterthought.

---

## Audience

This documentation is intended for:

- Contributors and maintainers
- Architects and reviewers
- Future you

If something is unclear here, the system is not documented well enough.

---

## Related Locations

- Application code: `/src`
- Static assets: `/public`
- Build configuration: root project files

---

*This documentation set represents the intended design of the system.
Code changes should preserve this intent unless an explicit design decision
is made to change it.*