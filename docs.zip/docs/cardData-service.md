
# cardData Service

This document defines the responsibilities, guarantees, and constraints of the
`cardData` service used by the Modern Master Strike single‑page application.

The purpose of this service is to **load all card-related data once**, prepare
derived lookup structures, and expose **pure query functions** for use by the
frontend without leaking data preparation logic into UI components.

---

## Location     src/services/cardData.ts

---

## Responsibilities

The `cardData` service is responsible for:

- Loading card metadata and card definitions at application startup
- Initializing the search engine and browser structures
- Building derived lookup maps for efficient UI use
- Exposing pure functions for querying, filtering, and searching cards
- Remaining independent of Vue, UI state, and the DOM

---

## Initialization Model

### Module-Scope Initialization

All initialization occurs **once**, at module import time.

When `cardData.ts` is imported by `App.vue`, the following happens immediately:

- A `CardSearchEngine` instance is created
- All cards are loaded into memory
- Metadata arrays are read and converted into lookup maps
- Browser/grouping structures are prepared

This design ensures:
- No repeated initialization
- No runtime data loading
- Predictable performance characteristics

---

## Data Loaded at Initialization

### Card Corpus

- **Source:** `CardSearchEngine.getAllCards()`
- **Storage:** Immutable in-memory array
- **Mutability:** None

The complete card library is loaded once and treated as read-only.

---

### Metadata

- **Source:** `Metadata.teamsArray`, `Metadata.setsArray`, etc.
- **Usage:** Building derived lookup structures
- **Mutability:** None

Metadata is used to translate internal identifiers into UI-friendly labels
and icons.

---

### Derived Lookups

The service builds the following lookup maps at initialization:

- **teamLookup**
  - Maps numeric team IDs to human-readable labels
- **setIconLookup**
  - Maps set labels to icon URLs

These are pure, derived structures and never change at runtime.

---

## Exposed API

The service exports **only pure query functions**.

### Read Accessors

- `getAllCards()`
- `getCategories()`
- `getSets()`
- `getTeams()`
- `getGroups(filterTypes?)`
- `getSetIcon(label)`
- `getTeamLabel(id)`

These functions:
- Do not mutate data
- Do not depend on UI state
- Are safe to call repeatedly

---

### Filtering Pipeline

#### `filterCards(options)`

Filtering is implemented as an **in-memory scan and sort pipeline** over the
preloaded card corpus.

The pipeline supports:
- Type filtering
- Group or card-name filtering (for special cases like Bystanders)
- Set filtering
- Team filtering
- Text search across name, subtitle, group, and description
- Stable sorting with secondary keys

Key properties:
- O(n) scan over in-memory data
- No external dependencies
- Deterministic output for a given input

---

### Search

#### `searchCards(query)`

Full-text search is delegated to the internal `CardSearchEngine`.

- Indexing is managed internally by the engine
- The service does not rebuild or modify the index
- The service simply forwards queries

---

## Explicit Non-Responsibilities

The `cardData` service **must never**:

- Reference Vue APIs (`ref`, `computed`, `watch`)
- Depend on UI state or component lifecycle
- Perform DOM operations
- Fetch network resources at runtime
- Mutate card data
- Manage modal or navigation state

Any of the above indicates a violation of the service boundary.

---

## Performance Invariants

The following behaviors are intentional and must be preserved:

- All card data loads once at startup
- All filtering happens in memory
- No data reloads occur during runtime
- Search index is reused across queries
- Static assets (images) are handled by the browser, not this service

Changes to these invariants should be treated as architectural changes and
reflected in the documentation.

---

## Rationale

This service exists to enforce a **clear separation of concerns**:

- Application logic prepares and owns data
- The frontend reacts to data changes declaratively
- Runtime interactions do not re-trigger heavy processing

This makes the application predictable, performant, and easy to reason about.

---

## Related Documentation

- `docs/data-sources.md`
- `docs/runtime-state-model.md`
- `docs/performance-invariants.md`
- `docs/test-boundaries.md`
