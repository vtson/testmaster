# Test Boundaries

This document defines the testing boundaries for the Modern Master Strike
single‑page application.

The goal is to ensure that tests reinforce the intended architecture:
- Services are deterministic and pure
- UI behavior is reactive and declarative
- Performance characteristics are preserved

---

## Testing Philosophy

The application follows a **clear separation of concerns**:

- Application logic prepares and owns data
- The frontend reacts to data changes
- Static assets are passive

Tests should mirror this structure.

---

## What to Test

### 1. Application Logic (Service Layer)

**Location:**  src/services/cardData.ts

This layer contains the most testable logic and should have the highest test coverage.

#### ✅ What to test

- `filterCards(...)`
  - Filtering by type, group, set, and team
  - Text search behavior (name, subtitle, group, description)
  - Sorting rules (primary and secondary keys)
- `getGroups(filterTypes)`
  - Special cases where groups collapse to card names
- `getSets()`
  - Unique set extraction and sorting
- `getTeams()`
  - Team filtering and labeling logic
- Lookup helpers (`getSetIcon`, `getTeamLabel`)

**Test characteristics:**
- Pure inputs → pure outputs
- No Vue dependencies
- No DOM access
- No network access

---

### 2. Runtime State Logic (Derived State)

**Location:**  src/App.vue

This layer should be tested **lightly**, focusing on correctness rather than exhaustive coverage.

#### ✅ What to test

- Derived values recompute when inputs change
- Watchers clean up invalid selections
- Modal state transitions (`selectedCard` set / cleared)

**Recommended approach:**
- Use shallow component tests
- Assert computed outputs, not implementation details

---

### 3. Component Integration

**Components:**
- `AppSidebar`
- `CardGallery`
- `CardModal`

#### ✅ What to test

- Props are rendered correctly
- Emitted events update state as expected
- No component performs data preparation

These tests ensure **wiring correctness**, not business logic.

---

## What NOT to Test

### ❌ Do not test Vue internals

- Vue reactivity mechanics
- DOM diffing or rendering behavior
- Computed invalidation logic

Vue already guarantees these behaviors.

---

### ❌ Do not test static assets

- Image loading
- Browser caching behavior
- Asset file existence at runtime

These are browser responsibilities.

---

### ❌ Do not test initialization timing

- Module import order
- Exact timing of service initialization
- Search index creation internals

These are implementation details and may change without affecting behavior.

---

## Performance-Sensitive Test Rules

Tests must not:

- Trigger repeated service initialization
- Rebuild search indices
- Introduce artificial async behavior
- Mock data loading in a way that violates load‑once assumptions

If a test requires such behavior, it likely crosses a boundary.

---

## Anti‑Patterns (Testing Smells)

The following indicate tests that violate architectural intent:

- Mocking Vue `ref()` or `computed()`
- Asserting on DOM structure instead of rendered meaning
- Testing filtering logic through UI components
- Introducing fake network layers for card data

---

## Test Layer Summary

| Layer | Coverage Level | Focus |
|-----|----------------|-------|
| Service Logic | High | Correctness, determinism |
| Runtime State | Medium | Reactivity, cleanup |
| UI Components | Low | Wiring and rendering |
| Static Assets | None | Browser responsibility |

---

## Relationship to the Flow Diagram

- **C‑nodes (C1–C3)** → unit tests
- **Reactive / Derived Data** → computed state tests
- **B‑nodes (B3–B5)** → shallow integration tests
- **Static Assets** → excluded from tests

This alignment ensures tests follow the same mental model as the architecture.

---

## Change Management

When adding new features:

1. Identify which layer the change belongs to
2. Add tests only at that layer
3. Avoid crossing boundaries “just for convenience”

Testing should **lock in intent**, not encode incidental behavior.

---

## Related Documentation

- `docs/data-sources.md`
- `docs/cardData-service.md`
- `docs/runtime-state-model.md`
- `docs/performance-invariants.md`