
# Contributor Onboarding Guide

Welcome to the Modern Master Strike single‑page application.

This guide helps new contributors understand **how the system is structured**,
**where to make changes**, and **how to avoid breaking architectural guarantees**.

If you read only one document before coding, read this one.

---

## Start Here (Required Reading)

Before making any changes, review these documents **in order**:

1. **Flow Diagram**  
   `docs/flow-diagram.pdf`  
   Explains how the system initializes and how runtime interactions work.

2. **Architecture Index**  
   `docs/README.md`  
   Links all architectural documents and explains how they fit together.

3. **Service Contract**  
   `docs/cardData-service.md`  
   Defines what application logic is allowed to do.

Skipping these steps will likely result in accidental architecture violations.

---

## Mental Model (5 Minutes)

The application is built around a simple idea:

> **Load all card data once, then reactively derive and render everything else.**

Key implications:
- No runtime data fetching
- No imperative rendering
- No UI logic inside services
- No data preparation inside components

If a change violates any of these, it is likely incorrect.

---

## Repository Orientation
.
├─ src/
│  ├─ main.ts            # Application bootstrap
│  ├─ App.vue            # Root component & runtime state
│  ├─ services/
│  │  └─ cardData.ts     # Application logic (data + filtering)
│  └─ components/        # Presentational UI components
├─ public/
│  └─ CardImages/        # Static card images (lazy loaded)
├─ docs/                 # Architecture & design documentation
└─ README.md

---

## Where to Make Changes

### UI Changes (Layout, Styling, Interaction)

- Location: `src/components/`
- Safe changes:
  - Styling
  - Layout
  - Component composition
- Not allowed:
  - Filtering logic
  - Data preparation
  - Service calls

---

### Filtering / Search Logic

- Location: `src/services/cardData.ts`
- This is the **only place** filtering and search logic should live.
- Changes here must:
  - Preserve immutability
  - Avoid runtime I/O
  - Respect performance invariants

---

### Runtime State Changes

- Location: `src/App.vue`
- Use `ref()` for mutable state
- Use `computed()` for derived state
- Never mutate derived values directly

---

## Common Pitfalls (Please Avoid)

❌ Fetching card data in response to user actions  
❌ Adding filtering logic inside components  
❌ Mutating card objects  
❌ Rebuilding search indices at runtime  
❌ Introducing background timers or polling  
❌ Mixing UI state with application logic  

If you feel tempted to do one of these, pause and review the docs.

---

## Testing Expectations

Refer to:
- `docs/test-boundaries.md`

In short:
- Service logic → unit tests
- UI wiring → shallow integration tests
- Vue internals → not tested
- Static assets → not tested

---

## Performance Expectations

Refer to:
- `docs/performance-invariants.md`

Key rules:
- Data loads once
- Filtering is in memory
- Rendering is reactive
- Assets load lazily

Violations must be intentional and documented.

---

## Making Architectural Changes

If your change affects:
- Data loading
- Service responsibilities
- Runtime state flow
- Performance behavior

Then you must:
1. Update the relevant document in `/docs`
2. Update the flow diagram if needed
3. Explain the change in your commit or PR

Architecture documentation is part of the system.

---

## When in Doubt

Ask yourself:
> “Which layer does this belong to?”

If the answer is unclear, the design likely needs clarification **before coding**.

---

## Final Note

This project values:
- Clarity over cleverness
- Predictability over flexibility
- Intentional design over accidental behavior

If you preserve those values, your contributions will fit naturally.

Welcome aboard.