# Data Source Inventory

This document describes all data sources used by the Modern Master Strike
single‑page application, when they are loaded, who owns them, and whether
they are mutable at runtime.

This inventory is a **living document** and should be updated whenever a new
data source is introduced or an existing one changes behavior.

---

## Overview

The application follows a **load-once, derive-many** model:

- All core card data and metadata are loaded once during initialization
- Runtime behavior operates entirely on in‑memory data
- Static assets are fetched lazily by the browser when needed

---

## Data Sources

### Card Metadata

- **Location:** `src/lib/master-strike-data/dist/metadata/*.js`
- **Loaded When:** Application initialization (module import)
- **Owner:** `src/services/cardData.ts`
- **Mutable:** No

**Description:**  
Lookup tables for card types, sets, teams, keywords, and rules. Used to
build derived lookups such as team labels and set icons.

---

### Card Definitions (Card Corpus)

- **Location:** `src/lib/master-strike-data/dist/definitions/cards/*.js`
- **Loaded When:** Application initialization
- **Owner:** `src/services/cardData.ts`
- **Mutable:** No

**Description:**  
The complete set of card definitions exposed via `CardSearchEngine`.
Loaded once and cached as an immutable in‑memory collection.

---

### Search Engine & Browser Structure

- **Location:** `src/lib/master-strike-data/dist/search/*`
- **Loaded When:** Application initialization
- **Owner:** `src/services/cardData.ts`
- **Mutable:** No

**Description:**  
Provides grouping, browsing, and full‑text search capabilities.
Search indexing is managed internally by `CardSearchEngine`.

---

### Derived Lookups

- **Location:** Built at runtime in `cardData.ts`
- **Loaded When:** Application initialization
- **Owner:** `src/services/cardData.ts`
- **Mutable:** No

**Examples:**
- `teamLookup` (team ID → label)
- `setIconLookup` (set label → icon URL)

**Description:**  
Derived maps built from metadata to simplify UI rendering and filtering.

---

### Filtered Card Results

- **Location:** Vue `computed()` values in `App.vue`
- **Loaded When:** Runtime
- **Owner:** Frontend (Vue SPA)
- **Mutable:** Yes (derived)

**Description:**  
Computed results produced by calling `filterCards(...)` with the current
filter and search state. Recomputed automatically when inputs change.

---

### UI State (Filters & Selection)

- **Location:** Vue `ref()` state in `App.vue`
- **Loaded When:** Runtime
- **Owner:** Frontend (Vue SPA)
- **Mutable:** Yes

**Examples:**
- `searchQuery`
- `selectedTypes`, `selectedGroups`, `selectedSets`, `selectedTeams`
- `sortAsc`, `sortByGroup`
- `selectedCard`

---

### Card Images

- **Location:** `public/CardImages/*.webp`
- **Loaded When:** Runtime, on demand
- **Owner:** Browser
- **Mutable:** No

**Description:**  
Static image assets fetched lazily when a card is viewed.
Caching is handled by the browser.

---

## Invariants

- No card data is fetched from the network at runtime
- All filtering is performed in memory
- Static assets are passive and never execute code
- Initialization runs once per page load

Violations of these invariants should be treated as architectural changes
and reflected in this document.