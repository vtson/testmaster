# Performance Invariants

This document defines the performance‑critical invariants of the
Modern Master Strike single‑page application.

These invariants are **intentional design choices**. Any change that violates
them should be treated as an architectural change and reviewed accordingly.

---

## Core Performance Model

The application follows a **load‑once, compute‑many, render‑reactively** model:

- All card data and metadata are loaded once at initialization
- All runtime interactions operate on in‑memory data
- UI updates are driven by reactive state changes
- Static assets are fetched lazily by the browser

This model prioritizes predictable performance and responsiveness.

---

## Invariant 1: No Runtime Data Fetching

- All card metadata, card definitions, and search structures are loaded at startup
- No network requests are made to retrieve card data during runtime
- Runtime behavior must not trigger data reloads

✅ Acceptable:
- Importing static modules at build or initialization time

❌ Not acceptable:
- Fetching JSON or card data in response to user actions

---

## Invariant 2: In‑Memory Filtering Only

- Filtering is implemented as an in‑memory scan and sort pipeline
- The `filterCards(...)` function operates on preloaded data
- Complexity is linear with respect to the number of cards

✅ This ensures:
- Stable and predictable performance
- No I/O during user interaction
- Easy reasoning about performance costs

---

## Invariant 3: Search Index Is Reused

- Full‑text search is delegated to `CardSearchEngine`
- Index construction is managed internally by the engine
- The index is not rebuilt during runtime

✅ This avoids:
- Expensive re‑indexing
- UI stalls during search
- Duplicate indexing logic in the frontend

---

## Invariant 4: Reactive Rendering Only

- UI rendering is driven exclusively by Vue reactivity
- No imperative DOM updates are allowed
- No manual re‑render triggers exist

✅ Rendering occurs automatically when:
- Reactive `ref()` values change
- Derived `computed()` values are invalidated

---

## Invariant 5: Stateless Services

- Application services (`cardData`) are stateless at runtime
- Services expose pure query functions
- Services do not depend on UI lifecycle or state

✅ Service initialization is allowed only at module import time.

---

## Invariant 6: Lazy Asset Loading

- Card images are loaded only when needed
- The browser controls caching behavior
- No preloading of image assets at startup

✅ This minimizes:
- Initial load time
- Memory footprint
- Unnecessary network usage

---

## Invariant 7: Predictable Memory Footprint

- Card data is stored once in memory
- Derived results are not cached beyond Vue reactivity
- No duplicated card structures are created

✅ Memory usage scales linearly with card count.

---

## Invariant 8: No Background Work

- No background threads, workers, or timers are used
- No polling or scheduled tasks exist
- All computation is user‑driven

✅ This keeps runtime behavior deterministic.

---

## Anti‑Patterns (Explicitly Forbidden)

The following patterns violate the intended performance model:

- Fetching card data during runtime
- Mutating card data structures
- Performing filtering inside UI components
- Rebuilding search indices on each query
- Introducing service calls inside computed properties

Any introduction of these patterns must be justified and documented.

---

## Relationship to the Flow Diagram

These invariants correspond directly to the diagram:

- **Initialization phase** enforces load‑once behavior
- **Reactive / Derived Data** enforces compute‑many behavior
- **Runtime Interaction Loop** enforces render‑reactively behavior
- **Static Assets** enforce lazy loading

---

## Change Management

If a proposed change violates any invariant in this document:

1. Update this document first
2. Update the flow diagram
3. Justify the performance trade‑off explicitly

Performance changes should be intentional, not accidental.

---

## Related Documentation

- `docs/data-sources.md`
- `docs/cardData-service.md`
- `docs/runtime-state-model.md`
- `docs/test-boundaries.md`